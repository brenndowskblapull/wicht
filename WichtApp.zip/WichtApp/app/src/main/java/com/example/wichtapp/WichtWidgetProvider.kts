package com.example.wichtwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.widget.RemoteViews
import kotlin.random.Random

class WichtWidgetProvider : AppWidgetProvider() {
    private val handler = Handler()
    private var runnable: Runnable? = null
    private val delayMillis = 500L  // alle 0.5 Sekunden aktualisieren

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }

        startAnimationLoop(context, appWidgetManager, appWidgetIds)
    }

    private fun startAnimationLoop(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        runnable = object : Runnable {
            override fun run() {
                for (appWidgetId in appWidgetIds) {
                    updateWidget(context, appWidgetManager, appWidgetId)
                }
                handler.postDelayed(this, delayMillis)
            }
        }
        handler.post(runnable!!)
    }

    private fun updateWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_layout)

        // Beispiel: zufälliges Bild setzen für "Animation"
        val frame = Random.nextInt(1, 5) // z. B. 4 Frames
        val imageId = context.resources.getIdentifier("wicht_frame_$frame", "drawable", context.packageName)
        views.setImageViewResource(R.id.wicht_image, imageId)

        // Optionale Interaktion
        val intent = Intent(context, WichtWidgetProvider::class.java)
        val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.wicht_image, pendingIntent)

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
